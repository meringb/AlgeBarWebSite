//
//  AddClassroomTableViewCell.swift
//  AppsComps
//
//  Created by Brynna Mering on 2/23/17.
//  Copyright © 2017 appscomps. All rights reserved.
//

import UIKit

class AddClassroomTableViewCell: UITableViewCell {

    @IBOutlet var addButton: UIButton!
    
    @IBOutlet var addLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
