//
//  HelpViewController.swift
//  AppsComps
//
//  Created by WANCHEN YAO on 2/25/17.
//  Copyright © 2017 appscomps. All rights reserved.
//

import UIKit

class HelpViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
